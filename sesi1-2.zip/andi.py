nama = "Andhika Tedja"
umur = 17
hobi = ["masak", "main game", "coding"]
teman = ["Budi"]

def kenalan():
  print("salken, saya Andi")

def temenan(nama):
  teman.append(nama)
  print(teman)