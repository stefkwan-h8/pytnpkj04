nama = "Cindy Sutrisno"
umur = 21
hobi = ["masak", "sepeda"]
teman = ["Andi"]

def kenalan():
  print("salam, saya Cindy Sutrisno")

def temenan(nama):
  teman.append(nama)
  print(teman)