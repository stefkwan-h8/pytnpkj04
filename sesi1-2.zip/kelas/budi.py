nama = "Budi Budiman"
umur = 27
hobi = ["main game", "coding"]
teman = ["Andi"]

def kenalan():
  print("halooo, saya Budi")

def temenan(nama):
  teman.append(nama)
  print(teman)